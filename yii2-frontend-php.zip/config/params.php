<?php
$url = ($_SERVER['HTTP_HOST'] == 'localhost'?'http://localhost/micro-backend/web/v1/':'https://portifolio-chayam.000webhostapp.com/micro-backend/v1/');
return [
    'token' => '123456',
    'endpoint' => $url,
];
